#!/bin/bash
./qemu-mipsel-static no_risc_no_future